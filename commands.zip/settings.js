require("./server/data1.js")

// >~~~~~~ Setting Bot & Owner  ~~~~~~~< //
global.owner = "6282291572138"
global.namabot = "pian Bot" 
global.namaowner = "pian"
global.linkgc = 'https://chat.whatsapp.com/IYZ8wTwKKSWCqYd4dbR9O'
global.packname = "pian"
global.author = "pian"
global.image = "https://files.catbox.moe/w2yzle.jpg"


// >~~~~~~~~ Setting Channel ~~~~~~~~~< //
global.idsaluran = "12036341180477677@newsletter"
global.namasaluran = "!- pian Marketplace"
global.linksaluran = "https://whatsapp.com/channel/0029Vb8cgMEH5JqiOEdbH1t"

// >~~~~ Setting Grup Reseller Panel ~~~~~< //
global.linkgrupresellerpanel = ""
global.apidigitalocean = ""


// >~~~~~~~~ Setting Payment ~~~~~~~~~< //
global.dana = "085624297893"
global.ovo = "Belum tersedia"
global.gopay = "Belum tersedia"
global.qris = "https://files.catbox.moe/uadqj0.jpg"


// >~~~~~~~ Setting Orderkuota ~~~~~~~~< //

global.QrisOrderKuota = "00020101021126670016COM.NOBUBANK.WWW01189360050300000879140214621103778158240303UMI51440014ID.CO.QRIS.WWW0215ID20243511142180303UMI5204541153033605802ID5920SKYZOPEDIA OK20882436009SIJUNJUNG61052751162070703A0163042A2F"
global.ApikeyOrderKuota = " "
global.IdMerchant = " "
global.pinH2H = " "
global.passwordH2H = ""

global.ApikeyRestApi = "free"


// >~~~~~~~~ Setting Api Panel ~~~~~~~~< //

global.egg = "15" // Isi id egg
global.nestid = "5" // Isi id nest
global.loc = "1" // Isi id location
global.domain = ""
global.apikey = "" // Isi api ptla
global.capikey = "" // Isi api ptlc

// >~~~~~~ Setting Api Cloudflare ~~~~~~~< //

global.apitoken_cloudflare = ""
global.accountid_cloudflare = ""
global.email_cloudflare = ""

// >~~~~~~~~ Setting Message ~~~~~~~~~< //

global.msg = {
wait: "Memproses . . .", 
owner: "Fitur ini khusus untuk owner!", 
group: "Fitur ini untuk dalam grup!", 
private: "Fitur ini untuk dalam private chat!", 
admin: "Fitur ini untuk admin grup!", 
botadmin: "Fitur ini hanya untuk bot menjadi admin"
}


let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.cyan("File Update => "), chalk.cyan.bgBlue.bold(`${__filename}`))
delete require.cache[file]
require(file)
})