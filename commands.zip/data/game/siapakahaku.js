const Games = [
  {
    "index": 0,
    "question": "Aku adalah sebuah kerajinan tangan. Aku memiliki bentuk seperti wajah manusia.",
    "answer": "Topeng"
  },
  {
    "index": 1,
    "question": "Aku menggunakan seragam coklat. Aku bertugas mengayomi masyarakat.",
    "answer": "Polisi"
  },
  {
    "index": 2,
    "question": "Aku sangat sepi pada malam hari. Aku selalu didatangi orang pada hari tertentu. Aku adalah sebuah tempat untuk beristirahat yang panjang.",
    "answer": "Kuburan"
  },
  {
    "index": 3,
    "question": "Aku disukai anak-anak untuk sarapan. Aku sering ada di dalam roti. Kebanyakan rasa aku adalah stroberi atau nanas.",
    "answer": "Selai"
  },
  {
    "index": 4,
    "question": "Aku tidak terlihat. Hanya orang-orang tertentu yang dapat melihat saya. Aku juga sangat menarik untuk diperbincangkan.",
    "answer": "Hantu"
  },
  {
    "index": 5,
    "question": "Aku berada di dalam tubuh manusia. Aku keluar jika ada yang terluka. Aku berwarna merah.",
    "answer": "Darah"
  },
  {
    "index": 6,
    "question": "Aku sejenis binatang. Semua bagian tubuh aku ada di kepala. Aku bisa menyebabkan gatal.",
    "answer": "Kutu"
  },
  {
    "index": 7,
    "question": "Tubuh aku panjang, tapi aku bukan ular. Aku bisa mengikat apa saja.",
    "answer": "Tali"
  },
  {
    "index": 8,
    "question": "Aku tumbuh di daerah pegunungan. Aku sejenis sayuran. Aku berwarna hijau dan bisa juga ungu. Aku memiliki bentuk yang bulat.",
    "answer": "Kubis"
  },
  {
    "index": 9,
    "question": "Aku dipakai di kepala. Tidak sembarangan orang bisa memakainya. Aku terbuat dari emas dengan batu mulia di sekelilingnya.",
    "answer": "Mahkota"
  },
  {
    "index": 10,
    "question": "Aku terbuat dari kain. Bentuk aku bermacam-macam, aku untuk menutupi jendela.",
    "answer": "Tirai"
  },
  {
    "index": 11,
    "question": "Bentukku bisa padat atau cair. Jika digosok aku akan berbuih. Aku ada di kamar mandi.",
    "answer": "Sabun"
  },
  {
    "index": 12,
    "question": "Tubuhku keras dan panjang. Rasaku manis, tapi aku bukan gula.",
    "answer": "Tebu"
  },
  {
    "index": 13,
    "question": "Aku memiliki cahaya. Cahaya aku dapat menyehatkan. Apabila aku datang biasanya banyak orang yang ke pantai.",
    "answer": "Sore"
  },
  {
    "index": 14,
    "question": "Tubuhku dari besi. Gigiku tajam dan banyak. Aku suka memotong.",
    "answer": "Gergaji"
  },
  {
    "index": 15,
    "question": "Kalau demam, aku sering dikompres air hangat. Kalau berpikir keras, aku sering dipegang. Kalau lupa, aku sering ditepuk.",
    "answer": "Dahi"
  },
  {
    "index": 16,
    "question": "Aku suka memainkan peran. Sering muncul di panggung televisi dan film. Aku juga terkenal. Aku berjenis kelamin pria.",
    "answer": "Aktor"
  },
  {
    "index": 17,
    "question": "Aku bisa menyalakan lampu. Tentu saja aku bisa mematikan lampu. Tapi tanpa listrik aku tidak ada gunanya.",
    "answer": "Saklar"
  },
  {
    "index": 18,
    "question": "Aku lahir di Arab. Aku tinggal dan besar pun di Arab. Tapi aku sama sekali tidak bisa Bahasa Arab.",
    "answer": "Unta"
  },
  {
    "index": 19,
    "question": "Badanku kecil panjang. Rambutku cuma satu. Aku muncul saat gelap gulita.",
    "answer": "Lilin"
  },
  {
    "index": 20,
    "question": "Aku laksana semut beriring, hanya pada laki-laki saja. Munculnya pun di bagian tertentu saja.",
    "answer": "Kumis"
  },
  {
    "index": 21,
    "question": "Aku digunakan saat memasak. Tubuhku dapat melukai. Aku sangat tajam. Aku terbuat dari stainless.",
    "answer": "Pisau"
  },
  {
    "index": 22,
    "question": "Aku adalah kotak yang dapat berbicara dan dapat menghibur orang. Aku juga penuh warna.",
    "answer": "Televisi"
  },
  {
    "index": 23,
    "question": "Pagi, siang, sore, dan malam aku bekerja tanpa henti dan terus berputar-putar, bila tidak matilah aku.",
    "answer": "Jam"
  },
  {
    "index": 24,
    "question": "Aku sembunyi tapi kepalaku selalu kelihatan.",
    "answer": "Paku"
  },
  {
    "index": 25,
    "question": "Aku hidup dengan listrik. Bagian bawahku sangat panas. Bagian bawahku dari logam. Kegunaanku untuk merapikan baju.",
    "answer": "Setrika"
  },
  {
    "index": 26,
    "question": "Aku adalah buah. Kalau masak warnaku kuning. Aku berbentuk lonjong. Aku untuk pencuci mulut.",
    "answer": "Pisang"
  },
  {
    "index": 27,
    "question": "Aku untuk membawa barang. Aku berwarna-warni. Aku dibawa ke sekolah. Aku biasanya di punggung.",
    "answer": "Tas"
  },
  {
    "index": 28,
    "question": "Aku sangat panas. Aku bisa melenyapkan sesuatu. Aku akan besar dengan angin. Aku takut dengan air.",
    "answer": "Api"
  },
  {
    "index": 29,
    "question": "Tebak siapakah aku? Aku terbuat dari kayu. Aku punya 4 kaki. Aku bisa patah. Aku digunakan untuk duduk.",
    "answer": "Kursi"
  },
  {
    "index": 30,
    "question": "Aku adalah hewan. Aku punya 4 kaki. Aku pemakan rumput. Aku berwarna putih.",
    "answer": "Sapi"
  },
  {
    "index": 31,
    "question": "Walaupun dibeli dalam waktu yang berbeda-beda, habisnya selalu dalam waktu bersamaan.",
    "answer": "Kalender"
  },
  {
    "index": 32,
    "question": "Aku bercahaya. Kadang aku berwarna-warni. Aku hidup dengan listrik. Aku bermanfaat di kegelapan.",
    "answer": "Lampu"
  },
  {
    "index": 33,
    "question": "Aku berwujud cair. Aku berwarna bening. Aku sangat dibutuhkan untuk hidup.",
    "answer": "Air"
  },
  {
    "index": 34,
    "question": "Aku adalah hewan. Aku mempunyai tanduk. Aku pemakan rumput. Kadang aku dijadikan sate.",
    "answer": "Kambing"
  },
  {
    "index": 35,
    "question": "Aku digunakan saat tidur. Aku sangat lembut. Aku lebar dan panjang. Aku selalu menghangatkan.",
    "answer": "Selimut"
  },
  {
    "index": 36,
    "question": "Aku termasuk hewan melata. Aku pemakan daging. Gigitanku mengandung racun. Aku tidak mempunyai kaki.",
    "answer": "Ular"
  },
  {
    "index": 37,
    "question": "Aku musuhnya air. Kadang aku untuk memasak. Aku berwujud cair. Aku sangat licin.",
    "answer": "Minyak"
  },
  {
    "index": 38,
    "question": "Aku terbuat dari kapas. Aku digunakan untuk tidur. Aku sangat empuk. Bentukku persegi panjang.",
    "answer": "Bantal"
  },
  {
    "index": 39,
    "question": "Aku sangat empuk. Aku bermacam-macam motif. Aku berada di ruang tamu. Biasanya aku untuk duduk.",
    "answer": "Sofa"
  },
  {
    "index": 40,
    "question": "Aku terbuat dari kayu. Aku berbentuk kotak. Aku ada pintunya. Kadang aku ada kacanya.",
    "answer": "Lemari"
  },
  {
    "index": 41,
    "question": "Aku sangat lembut. Aku berwarna putih. Bentukku persegi panjang. Biasanya aku untuk mengusap sesuatu yang kotor.",
    "answer": "Tisu"
  },
  {
    "index": 42,
    "question": "Aku merah, aku biru, akupun hijau. Aku juga sering kau kunjungi.",
    "answer": "Google"
  },
  {
    "index": 43,
    "question": "Kau cekik leherku. Kau gerayangi tubuhku. Akupun tertawa.",
    "answer": "Gitar"
  },
  {
    "index": 44,
    "question": "Aku berbentuk bundar. Biasanya berwarna putih. Bila jatuh, aku bisa pecah. Aku dipakai saat makan.",
    "answer": "Piring"
  },
  {
    "index": 45,
    "question": "Aku adalah ruangan. Di ruanganku ada kompornya. Aku tempat untuk memasak.",
    "answer": "Dapur"
  },
  {
    "index": 46,
    "question": "Aku sebuah profesi. Aku biasanya di rumah sakit. Aku memeriksa orang sakit.",
    "answer": "Dokter"
  },
  {
    "index": 47,
    "question": "Aku sangat lucu. Aku adalah mainan. Aku dimainkan oleh anak-anak. Biasanya aku berbentuk tiruan hewan, manusia, dll.",
    "answer": "Boneka"
  },
  {
    "index": 48,
    "question": "Aku berbentuk bulat. Aku sangat enak. Biasanya aku untuk lauk. Aku ada kuningnya di tengah.",
    "answer": "Telur"
  },
  {
    "index": 49,
    "question": "Aku termasuk itik. Aku menghasilkan telur. Telurku berwarna biru.",
    "answer": "Bebek"
  },
  {
    "index": 50,
    "question": "Aku bagian dari tubuh. Aku ada 2 kiri dan kanan. Aku merupakan panca indra.",
    "answer": "Telinga"
  },
  {
    "index": 51,
    "question": "Aku sangat mengkilap. Aku berwarna kuning. Kadang aku berbentuk cincin.",
    "answer": "Emas"
  },
  {
    "index": 52,
    "question": "Aku adalah hewan. Aku bisa menarik gerobak. Biasanya aku digunakan untuk delman.",
    "answer": "Kuda"
  },
  {
    "index": 53,
    "question": "Aku sebuah pulau. Aku termasuk wilayah WITA. Banyak wisatawan asing di sini.",
    "answer": "Bali"
  },
  {
    "index": 54,
    "question": "Aku adalah satelit alami bumi. Aku berbentuk bulat. Aku menyinari di malam hari.",
    "answer": "Bulan"
  },
  {
    "index": 55,
    "question": "Aku adalah alat tulis. Aku selalu dipegang ibu jari dan telunjuk. Aku untuk menulis buku.",
    "answer": "Pensil"
  },
  {
    "index": 56,
    "question": "Aku berwujud kain. Aku selalu dipakai manusia. Aku terdapat 3 lubang.",
    "answer": "Celana"
  },
  {
    "index": 57,
    "question": "Aku berupa cair. Aku tempat hidup ikan paus. Kapal pesiar selalu di atasku",
    "answer": "Laut"
  },
  {
    "index": 58,
    "question": "Aku berwarna putih. Aku berbentuk butir kecil. Aku rasanya asin.",
    "answer": "Garam"
  },
  {
    "index": 59,
    "question": "Aku berwujud cair. Aku salah satu bahan bakar. Aku tersedia di POM.",
    "answer": "Pertamax"
  },
  {
    "index": 60,
    "question": "Aku adalah sebuah tempat. Aku penghubung antar kota. Aku tempat pemberhentian kereta api.",
    "answer": "Stasiun"
  },
  {
    "index": 61,
    "question": "Aku termasuk benda padat. Tubuhku sangat keras. Aku sering digunakan untuk pondasi rumah.",
    "answer": "Batu"
  },
  {
    "index": 62,
    "question": "Aku berbentuk bulat. Aku sangat panas. Aku sebagai pusat tata surya.",
    "answer": "Matahari"
  },
  {
    "index": 63,
    "question": "Aku pasti sepasang. Aku sangat keras. Tidak semua hewan mempunyai aku. Aku di atas kepala.",
    "answer": "Tanduk"
  },
  {
    "index": 64,
    "question": "Aku digunakan untuk minum. Aku berbentuk tabung tanpa tutup. Aku bermacam-macam. Aku terbuat dari atom plastik.",
    "answer": "Cangkir"
  },
  {
    "index": 65,
    "question": "Aku berbentuk bundar. Aku tempatnya di atas kepala. Kegunaanku untuk menutupi dari panas.",
    "answer": "Topi"
  },
  {
    "index": 66,
    "question": "Semua orang hormat padaku. Setiap negara pasti punya aku. Aku terbuat dari kain.",
    "answer": "Bendera"
  },
  {
    "index": 67,
    "question": "Aku sebuah profesi. Aku yang mengurusi sawah.",
    "answer": "Petani"
  },
  {
    "index": 68,
    "question": "Aku hidup dengan solar. Aku beroda 4. Aku berbentuk badan besar.",
    "answer": "Truck"
  },
  {
    "index": 69,
    "question": "Aku berbentuk kotak. Aku berwarna merah. Aku biasanya untuk membangun rumah.",
    "answer": "Bata"
  },
  {
    "index": 70,
    "question": "Tubuhku panjang. Aku selalu diinjak. Aku terbentang di sungai.",
    "answer": "Jembatan"
  },
  {
    "index": 71,
    "question": "Aku adalah alat bersih-bersih. Badanku terbuat dari kayu. Aku sering bersentuhan dengan lantai.",
    "answer": "Sapu"
  },
  {
    "index": 72,
    "question": "Aku berbentuk tabung. Badanku terdiri dari 2 lapis. Biasanya aku digunakan untuk menyimpan air panas.",
    "answer": "Termos"
  },
  {
    "index": 73,
    "question": "Tebak siapakah aku? Aku terbuat dari kain. Aku berbentuk persegi. Biasanya aku untuk mengelap meja.",
    "answer": "Serbet"
  },
  {
    "index": 74,
    "question": "Aku akan hidup dengan listrik. Aku banyak di kantor. Biasanya di dalamku ada MS Officenya.",
    "answer": "Komputer"
  },
  {
    "index": 75,
    "question": "Aku berbentuk kotak. Aku biasanya di dapur. Aku bisa mengeluarkan api.",
    "answer": "Kompor"
  },
  {
    "index": 76,
    "question": "Aku adalah benda elektronik. Bentukku kotak. Aku bisa mengeluarkan suara.",
    "answer": "Radio"
  },
  {
    "index": 77,
    "question": "Aku sangat wangi. Aku dipakai di saat mandi. Aku diusap di rambut.",
    "answer": "Sampo"
  },
  {
    "index": 78,
    "question": "Aku adalah sebuah ruangan. Biasanya aku di samping rumah. Aku merupakan tempat mobil.",
    "answer": "Garasi"
  },
  {
    "index": 79,
    "question": "Aku adalah ruang bebas. Biasanya aku di depan rumah. Banyak macam-macam bunga di sini.",
    "answer": "Taman"
  },
  {
    "index": 80,
    "question": "Aku bagian dari hewan. Biasanya bentukku panjang. Aku selalu di bagian belakang hewan.",
    "answer": "Ekor"
  },
  {
    "index": 81,
    "question": "Aku termasuk burung. Ada yang menjadikanku sebagai simbol negara.",
    "answer": "Garuda"
  },
  {
    "index": 82,
    "question": "Aku termasuk sebuah profesi. Biasanya aku dipilih lewat pemilu. Aku merupakan orang no. 1 di sebuah provinsi.",
    "answer": "Gubernur"
  },
  {
    "index": 83,
    "question": "Aku adalah sebuah tempat. Aku sangat dingin. Aku ada yang Utara dan Selatan.",
    "answer": "Kutub"
  },
  {
    "index": 84,
    "question": "Aku adalah sebuah kota. Aku berada di Jawa Barat. Aku dijuluki Kota Hujan.",
    "answer": "Bogor"
  },
  {
    "index": 85,
    "question": "Aku berwujud cair. Aku berwarna hitam. Aku sangat bau. Aku kotoran dari pabrik.",
    "answer": "Limbah"
  },
  {
    "index": 86,
    "question": "Aku adalah macam olahraga. Aku dimainkan dengan bola. Aku ada 2 ring di masing-masing ujung lawan.",
    "answer": "Basket"
  },
  {
    "index": 87,
    "question": "Aku terbuat dari parasit. Aku ada pegangannya. Aku digunakan untuk berlindung dari panas dan hujan.",
    "answer": "Payung"
  },
  {
    "index": 88,
    "question": "Aku bagian dari tubuh. Warnaku putih. Salah satu dari aku disebut geraham.",
    "answer": "Gigi"
  },
  {
    "index": 89,
    "question": "Aku di atas meja. Biasanya terbuat dari kayu. Aku sebagai tempat puntung rokok.",
    "answer": "Asbak"
  },
  {
    "index": 90,
    "question": "Aku merupakan karya seni. Orang suka memajangku. Aku mempunyai estetika.",
    "answer": "Lukisan"
  },
  {
    "index": 91,
    "question": "Aku terbuat dari alumunium. Aku sebagai tempat baju. Aku selalu ditaruh di terik matahari.",
    "answer": "Jemuran"
  },
  {
    "index": 92,
    "question": "Aku berbentuk kotak. Bagian dalamku dingin. Aku membuat es.",
    "answer": "Kulkas"
  },
  {
    "index": 93,
    "question": "Aku bisa pecah. Setiap hari orang pasti memandangku. Aku bisa memantulkan sesuatu yang ada di hadapanku.",
    "answer": "Cermin"
  },
  {
    "index": 94,
    "question": "Aku dipunyai di setiap rumah. Aku tempat BAB.",
    "answer": "Toilet"
  },
  {
    "index": 95,
    "question": "Aku gelembung-gelembung kecil. Aku dihasilkan oleh sabun.",
    "answer": "Busa"
  },
  {
    "index": 96,
    "question": "Aku hidup dengan listrik. Aku berbentuk kotak. Kegunaanku untuk membuat roti.",
    "answer": "Oven"
  },
  {
    "index": 97,
    "question": "Aku adalah alat dapur. Aku berbentuk bulat. Aku digunakan untuk menumbuk bumbu.",
    "answer": "Cobek"
  },
  {
    "index": 98,
    "question": "Aku panjang seperti pipa. Badanku lentur. Kegunaanku untuk mengalirkan air.",
    "answer": "Selang"
  },
  {
    "index": 99,
    "question": "Saat aku jatuh, gerakku pelan. Saat aku naik, gerakku cepat.",
    "answer": "Ingus"
  },
  {
    "index": 100,
    "question": "Aku merah putih yang berselang. Tegap berdiri dan saling berhubungan. Mendekatkan yang jauh dan menjauhkan yang dekat.",
    "answer": "Tower"
  },
  {
    "index": 101,
    "question": "Jika kau sebut aku. Aku akan tidak berarti.",
    "answer": "Diam"
  },
  {
    "index": 102,
    "question": "Kau genggam aku. Terkadang kau tak mau jauh dariku. Di saat kamu pergi, aku menyertaimu. Dunia tampak sepi tanpa kehadiranku. Saat aku berteriak, kau langsung mencariku.",
    "answer": "Handphone"
  },
  {
    "index": 103,
    "question": "Aku bisa makan. Aku juga bisa dimakan. Aku hitam putih yang berperang.",
    "answer": "Catur"
  },
  {
    "index": 104,
    "question": "Aku selalu dikejar-kejar. Tapi walau sampai kapanpun, dia tidak akan pernah berhasil mendahuluiku.",
    "answer": "Roda"
  },
  {
    "index": 105,
    "question": "Aku selalu berpasangan. Aku kiri dan kanan. Aku dipake ke sekolah. Kadang aku tak bertali.",
    "answer": "Sepatu"
  },
  {
    "index": 106,
    "question": "Aku Bapak Proklamator Republik Indonesia.",
    "answer": "Soekarno"
  },
  {
    "index": 107,
    "question": "Aku adalah bagian pada kendaraan bermotor. Aku digunakan sebagai pembuangan gas.",
    "answer": "Knalpot"
  },
  {
    "index": 108,
    "question": "Aku adalah binatang. Aku bisa hidup di air dan di darat.",
    "answer": "Amfibi"
  },
  {
    "index": 109,
    "question": "Aku sebuah negara, aku juara Piala Eropa 2016.",
    "answer": "Portugal"
  },
  {
    "index": 110,
    "question": "Aku adalah mata uang, aku berasal dari negara Jepang.",
    "answer": "Yen"
  },
  {
    "index": 111,
    "question": "Aku salah satu panca indra manusia. Aku digunakan untuk mengecap.",
    "answer": "Lidah"
  },
  {
    "index": 112,
    "question": "Aku adalah sebuah planet. Aku terbesar dalam tata surya kita.",
    "answer": "Yupiter"
  },
  {
    "index": 113,
    "question": "Aku sebuah produk makanan ringan. Aku pernah beriklan di televisi. Aku memiliki moto: ‘Berapa Lapis? Ratusan’.",
    "answer": "Tango"
  },
  {
    "index": 114,
    "question": "Aku sejenis hewan. Aku hewan terkecil di dunia.",
    "answer": "Amuba"
  },
  {
    "index": 115,
    "question": "Aku adalah tumbuhan. Di seluruh tubuhku penuh dengan duri. Aku sering ditemukan di padang gurun yang gersang.",
    "answer": "Kaktus"
  },
  {
    "index": 116,
    "question": "Aku adalah nama gunung. Aku gunung tertinggi di dunia.",
    "answer": "Everest"
  },
  {
    "index": 117,
    "question": "Aku suka mempromosikan. Bisa seperti benda, jasa, dan ide. Aku juga bisa meningkatkan penjualan.",
    "answer": "Iklan"
  },
  {
    "index": 118,
    "question": "Kalo diucapkan 1 kali aku jauh. Diucapkan 2 kali aku jadi dekat.",
    "answer": "Langit"
  },
  {
    "index": 119,
    "question": "Saya adalah sebuah provinsi di Indonesia. Saya disusun oleh sebuah benda yang dicari ketika gelap. Jika huruf awal saya diganti, maka pekerjaan saya telah selesai.",
    "answer": "Lampung"
  },
  {
    "index": 120,
    "question": "Aku memiliki ukuran besar. Pada beberapa film, aku juga sesosok yang menyeramkan.",
    "answer": "Raksasa"
  },
  {
    "index": 121,
    "question": "Aku sebuah negara. Aku memiliki jumlah penduduk terbanyak di dunia.",
    "answer": "China"
  },
  {
    "index": 122,
    "question": "Aku adalah sebuah bangunan. Aku berbentuk segitiga. Aku digunakan sebagai tempat penguburan Firaun.",
    "answer": "Piramida"
  },
  {
    "index": 123,
    "question": "Aku sejenis kera. Aku adalah binatang yang dilindungi. Aku berasal dari Kalimantan dan Sumatra.",
    "answer": "Orangutan"
  },
  {
    "index": 124,
    "question": "Aku adalah sejenis buah-buahan, biasanya aku diparut untuk dijadikan santan.",
    "answer": "Kelapa"
  },
  {
    "index": 125,
    "question": "Aku adalah samudra. Aku samudra terluas di dunia.",
    "answer": "Pasifik"
  },
  {
    "index": 126,
    "question": "Aku salah satu bagian dari anggota tubuh. Tempatku di bagian wajah.",
    "answer": "Hidung"
  },
  {
    "index": 127,
    "question": "Aku adalah sebuah planet. Aku sangat jauh dari bumi. Aku planet keenam dari matahari.",
    "answer": "Saturnus"
  },
  {
    "index": 128,
    "question": "Aku adalah sebuah mata uang. Aku biasa dipake untuk melakukan pembayaran. Aku adalah mata uang virtual.",
    "answer": "Bitcoin"
  },
  {
    "index": 129,
    "question": "Aku terbuat dari kain. Aku dapat menyerap air. Aku digunakan untuk mengeringkan setelah mandi.",
    "answer": "Handuk"
  },
  {
    "index": 130,
    "question": "Ukuranku sangat kecil seperti butiran pasir. Rasaku sangat manis. Aku terbuat dari tanaman tebu.",
    "answer": "Gula"
  },
  {
    "index": 131,
    "question": "Aku merupakan makanan pokok. Aku berbentuk butiran kecil. Warnaku putih.",
    "answer": "Nasi"
  },
  {
    "index": 132,
    "question": "Aku adalah sebuah kota. Aku bagian dari Negara Kesatuan Republik Indonesia, letakku paling Utara Indonesia.",
    "answer": "Sabang"
  },
  {
    "index": 133,
    "question": "Aku bagian dari tubuh. Aku adalah sebutan untuk ibu jari tangan dan kaki.",
    "answer": "Jempol"
  },
  {
    "index": 134,
    "question": "Aku sejenis alat musik. Aku berasal dari masyarakat Sunda. Aku terbuat dari bambu.",
    "answer": "Angklung"
  },
  {
    "index": 135,
    "question": "Aku sejenis kesenian. Aku sangat terkenal. Aku berasal dari Ponorogo.",
    "answer": "Reog"
  },
  {
    "index": 136,
    "question": "Aku sejenis makanan. Biasanya aku berupa bubur sagu. Aku berasal dari Maluku dan Papua.",
    "answer": "Papeda"
  },
  {
    "index": 137,
    "question": "Aku adalah sebuah seni bela diri. Aku berasal dari Negara Jepang.",
    "answer": "Karate"
  },
  {
    "index": 138,
    "question": "Aku adalah sebuah tarian tradisional. Aku berasal dari Tionghoa. Biasanya aku menggunakan kostum menyerupai singa atau naga.",
    "answer": "Barongsai"
  },
  {
    "index": 139,
    "question": "Aku adalah sebuah bahasa. Aku merupakan bahasa resmi negara Filipina.",
    "answer": "Tagalog"
  },
  {
    "index": 140,
    "question": "Aku merupakan benua yang meliputi kutub Selatan bumi. Aku memiliki suhu yang sangat rendah.",
    "answer": "Antartika"
  },
  {
    "index": 141,
    "question": "Aku adalah sebutan untuk kerabat kandung. Aku adalah ayah dari masing-masing orang tua kita.",
    "answer": "Kakek"
  },
  {
    "index": 142,
    "question": "Aku makhluk berjenis kelamin perempuan. Aku berparas cantik. Aku berasal dari kahyangan.",
    "answer": "Bidadari"
  },
  {
    "index": 143,
    "question": "Aku adalah sejenis bangunan. Aku biasanya dijadikan tempat tinggal manusia.",
    "answer": "Rumah"
  },
  {
    "index": 144,
    "question": "Aku berbentuk butiran-butiran kering. Aku merupakan olahan dari padi.",
    "answer": "Beras"
  },
  {
    "index": 145,
    "question": "Aku tidak bisa jalan di darat. Apalagi di laut. Aku suka menembus awan. Aku bisa membawa banyak orang.",
    "answer": "Pesawat"
  },
  {
    "index": 146,
    "question": "Letak aku selalu di pojok. Aku ada pada segitiga siku-siku. Aku juga selalu ada di rumah.",
    "answer": "Sudut"
  },
  {
    "index": 147,
    "question": "Tubuh aku penuh duri. Orang lebih suka aku jika berwarna merah. Aku melambangkan perasaan cinta.",
    "answer": "Mawar"
  },
  {
    "index": 148,
    "question": "Aku adalah alat tulis. Aku berwarna putih. Aku berbentuk segi panjang. Aku hancur bila kena air.",
    "answer": "Buku"
  },
  {
    "index": 149,
    "question": "Tubuhku kebanyakan dibuat dari besi. Aku selalu memotong. Kalau separuh tubuhku hilang, maka aku tidak berguna lagi.",
    "answer": "Gunting"
  },
  {
    "index": 150,
    "question": "Tubuhku kecil mungil. Kalau sudah dibuka akan terlihat ujungku yang bulat lucu. Aku suka sekali diisap terutama anak-anak.",
    "answer": "Lolipop"
  },
  {
    "index": 151,
    "question": "Tebak siapakah aku? Aku adalah hewan. Aku bisa terbang. Aku sangat indah. Aku penghisap bunga.",
    "answer": "Kupu"
  },
  {
    "index": 152,
    "question": "Bentuk aku kecil hitam. Rasa aku sedikit asin. Aku sering diolah menjadi makanan ringan.",
    "answer": "Kuaci"
  },
  {
    "index": 153,
    "question": "Aku bukan benda cair, juga bukan benda padat. Jika aku muncul sekitarku pasti heboh.",
    "answer": "Kentut"
  },
  {
    "index": 154,
    "question": "Badanku penuh duri, tapi aku bukan buah. Wanita sangat suka akan diriku.",
    "answer": "Mawar"
  },
  {
    "index": 155,
    "question": "Aku terbuat dari besi. Aku digunakan untuk makan. Pasanganku adalah garpu.",
    "answer": "Sendok"
  },
  {
    "index": 156,
    "question": "Aku bersuara bila ada bahaya. Aku juga suka membangunkan orang tidur. Suara aku cukup keras.",
    "answer": "Alarm"
  },
  {
    "index": 157,
    "question": "Usia aku masih sangat muda. Bentuk aku mungil dan imut. Aku sangat menggemaskan.",
    "answer": "Bayi"
  },
  {
    "index": 158,
    "question": "Bentuk aku bulat. Ukuran aku bermacam-macam. Aku selalu digelindingkan, dilempar, bahkan ditendang.",
    "answer": "Bola"
  },
  {
    "index": 159,
    "question": "Bentuk aku bermacam-macam. Aku disukai anak-anak. Aku gampang rusak oleh benda tajam atau panas.",
    "answer": "Balon"
  },
  {
    "index": 160,
    "question": "Bentuk aku panjang. Warna tubuh aku oranye, katanya kelinci sangat suka aku.",
    "answer": "Wortel"
  },
  {
    "index": 161,
    "question": "Aku selalu membantu orang membawa barang. Ukuran aku bermacam-macam. Letak aku di punggung orang yang aku bantu.",
    "answer": "Ransel"
  },
  {
    "index": 162,
    "question": "Tubuh aku warna-warni. Aku muncul setelah hujan turun. Bentuk aku melengkung dengan indah.",
    "answer": "Pelangi"
  },
  {
    "index": 163,
    "question": "Aku disukai banyak orang. Aku memiliki cahaya yang terang, tapi cuma sekilas. Aku mengabadikan momen yang penting.",
    "answer": "Kamera"
  },
  {
    "index": 164,
    "question": "Bentuk aku panjang dan sedikit melengkung. Aku memiliki warna hijau dan kuning. Katanya aku disukai monyet.",
    "answer": "Pisang"
  },
  {
    "index": 165,
    "question": "Aku berbentuk gas. Aku ada jika ada air dan api.",
    "answer": "Uap"
  },
  {
    "index": 166,
    "question": "Aku dari golongan hewan. Aku sudah hampir punah. Bentuk aku seperti kadal raksasa.",
    "answer": "Komodo"
  },
  {
    "index": 167,
    "question": "Aku peninggalan masa lalu. Aku terbuat dari batu yang megah dan besar. Aku terletak dekat Yogyakarta.",
    "answer": "Borobudur"
  },
  {
    "index": 168,
    "question": "Tubuh aku mungil. Aku hidup berkelompok. Aku menghasilkan cairan yang manis.",
    "answer": "Lebah"
  },
  {
    "index": 169,
    "question": "Banyak orang yang sangat sulit mendefinisikan aku. Aku juga dapat membuat orang menjadi senang dan bahkan sangat sedih.",
    "answer": "Cinta"
  },
  {
    "index": 170,
    "question": "Aku sebuah senjata. Tubuh aku besar dan panjang. Aku memiliki peluru yang bulat, besar, dan berat.",
    "answer": "Meriam"
  },
  {
    "index": 171,
    "question": "Aku alat transportasi. Roda aku terbuat dari kayu. Aku harus ditarik oleh kuda.",
    "answer": "Andong"
  },
  {
    "index": 172,
    "question": "Aku sejenis hewan. Tubuh aku berbulu dan sangat lucu. Manusia sering menjadikan aku temannya.",
    "answer": "Kucing"
  },
  {
    "index": 173,
    "question": "Aku memiliki bentuk atas yang memanjang. Bagian bawahku berbentuk lingkaran. Aku dapat menampung air.",
    "answer": "Botol"
  },
  {
    "index": 174,
    "question": "Aku adalah buah. Bentukku bulat. Aku hanya ada di padang pasir.",
    "answer": "Kurma"
  },
  {
    "index": 175,
    "question": "Aku terbuat dari kayu. Setiap rumah pasti punya aku. Aku bisa dibuka dan ditutup.",
    "answer": "Pintu"
  },
  {
    "index": 176,
    "question": "Aku terbuat dari besi. Ada 2 roda di bagian bawahku. Aku bisa digunakan dengan cara dikayuh.",
    "answer": "Sepeda"
  },
  {
    "index": 177,
    "question": "Aku terbuat dari kain. Aku selalu dipasang di jendela.",
    "answer": "Gorden"
  },
  {
    "index": 178,
    "question": "Aku biasanya terbuat dari besi, kayu, atau tembok. Aku selalu dipasang mengelilingi rumah.",
    "answer": "Pagar"
  },
  {
    "index": 179,
    "question": "Aku bagian dari tumbuhan. Aku merupakan bagian dimana terjadi fotosintesis.",
    "answer": "Daun"
  },
  {
    "index": 180,
    "question": "Aku berwujud gas. Aku selalu dibutuhkan semua makhluk hidup.",
    "answer": "Oksigen"
  },
  {
    "index": 181,
    "question": "Aku berwujud cair, biasanya warnaku hitam. Aku jadi satu dengan printer.",
    "answer": "Tinta"
  },
  {
    "index": 182,
    "question": "Aku terbuat dari besi. Aku berbentuk kecil panjang. Selalu ada lubang di salah satu ujungku.",
    "answer": "Jarum"
  },
  {
    "index": 183,
    "question": "Aku sangat membantu siswa dalam menghitung. Aku sangat jago dalam menghitung. Di dalam diriku terdapat angka 1-9.",
    "answer": "Kalkulator"
  },
  {
    "index": 184,
    "question": "Aku termasuk hewan. Biasanya aku ada di hutan. Di bagian tubuhku penuh duri.",
    "answer": "Landak"
  },
  {
    "index": 185,
    "question": "Ketika muda aku tinggi. Ketika tua aku pendek.",
    "answer": "Lilin"
  },
  {
    "index": 186,
    "question": "Aku bisa bertambah, tapi aku tidak bisa berkurang.",
    "answer": "Umur"
  },
  {
    "index": 187,
    "question": "Aku ringan seperti bulu, namun manusia terkuat tidak bisa menahan aku lebih dari lima menit.",
    "answer": "Nafas"
  },
  {
    "index": 188,
    "question": "Aku bisa dipegang tapi tidak bisa disentuh.",
    "answer": "Janji"
  },
  {
    "index": 189,
    "question": "Aku bagian dari burung tapi tidak bisa terbang, namun aku bisa berada di lautan tanpa basah.",
    "answer": "Bayangan"
  },
  {
    "index": 190,
    "question": "Aku punya banyak lubang tapi aku dapat menyimpan air.",
    "answer": "Sponge"
  },
  {
    "index": 191,
    "question": "Aku kehilangan kepala ketika pagi dan punya lagi waktu malam.",
    "answer": "Bantal"
  },
  {
    "index": 192,
    "question": "Aku selalu diinjak-injak. Akupun juga dielus-elus.",
    "answer": "Tangga"
  },
  {
    "index": 193,
    "question": "Tebak siapakah aku? Aku memiliki sayap. Sayapku menyambung dengan kaki. Aku sangat suka beraktivitas di malam hari.",
    "answer": "Kelelawar"
  },
  {
    "index": 194,
    "question": "Aku sejenis hewan. Gigi aku tajam. Aku sangat galak pada orang jahat. Aku dipilih manusia untuk menjaganya.",
    "answer": "Anjing"
  },
  {
    "index": 195,
    "question": "Aku selalu dipotong tapi tetap tumbuh. Biasanya aku ada di tangan dan kaki.",
    "answer": "Kuku"
  },
  {
    "index": 196,
    "question": "Aku dapat menghibur orang. Aku biasanya ada di tempat karaoke. Aku mempunyai irama dan lirik.",
    "answer": "Lagu"
  },
  {
    "index": 197,
    "question": "Aku adalah sesuatu yang sering dinikmati ketika jam-jam istirahat umumnya malam hari. Aku biasanya empuk.",
    "answer": "Kasur"
  },
  {
    "index": 198,
    "question": "Aku nomor tiga, tapi bukan angka. Aku akan panas dan dingin pada saat yang sama, tapi tidak pada waktu yang sama. Semua orang dekat denganku, tapi tidak semua orang tahu namaku.",
    "answer": "Bumi"
  },
  {
    "index": 199,
    "question": "Aku sejenis buah-buahan. Rupaku bulat, kuning, hijau. Rasanya ada yang manis ada yang asam dan seger diolah saat panas.",
    "answer": "Jeruk"
  },
  {
    "index": 200,
    "question": "Aku memiliki bau yang kurang sedap. Badanku penuh dengan duri, namun di dalam tubuhku memiliki daging berwarna kuning yang enak.",
    "answer": "Durian"
  },
  {
    "index": 201,
    "question": "Saat aku ditekan, aku menampilkan kata. Saat aku dikombinasikan, aku mengeluarkan hal menarik.",
    "answer": "Keyboard"
  },
  {
    "index": 202,
    "question": "Aku memiliki tempat hitam dan putih. Aku memiliki raja dan aku juga memiliki lawan yang saling menyerang.",
    "answer": "Catur"
  },
  {
    "index": 203,
    "question": "Aku merupakan benda yang sering digunakan untuk digeser dan diklik.",
    "answer": "Mouse"
  },
  {
    "index": 204,
    "question": "Warnaku bermacam-macam, bentukku bermacam-macam pula. Semua orang menyukai aku. Aku identik dengan seorang wanita.",
    "answer": "Bunga"
  },
  {
    "index": 205,
    "question": "Warnaku putih, ada juga yang coklat dan cair serta penuh gizi. Aku juga bermanfaat bagi anak-anak dan dewasa.",
    "answer": "Susu"
  },
  {
    "index": 206,
    "question": "Aku datang tiba-tiba dan beramai-ramai.",
    "answer": "Hujan"
  },
  {
    "index": 207,
    "question": "Aku memiliki badan yang kecil. Aku juga selalu berkelompok dalam jumlah besar. Dalam hal apapun, kami selalu bekerja sama. Makanan yang aku suka berbau manis.",
    "answer": "Semut"
  },
  {
    "index": 208,
    "question": "Aku memiliki badan yang bulat. Warnaku hijau, kuning, dan merah ketika aku matang. Aku biasa digunakan untuk bahan masakan atau dimakan langsung.",
    "answer": "Tomat"
  },
  {
    "index": 209,
    "question": "Aku hidup di dalam tanah. Namun batangku hidup di luar dan daunku suka di lalapan.",
    "answer": "Singkong"
  },
  {
    "index": 210,
    "question": "Bentukku panjang, keriting, direbus, pake bumbu langsung makan.",
    "answer": "Mie"
  },
  {
    "index": 211,
    "question": "Aku disimpan di saku, terdapat tempat kartu, uang, tagihan. Aku sering dibawa kemana-mana.",
    "answer": "Dompet"
  },
  {
    "index": 212,
    "question": "Aku dipake di jari. Aku biasanya dibuat untuk tunangan atau pernikahan. Aku berwarna emas, perak, atau perunggu.",
    "answer": "Cincin"
  },
  {
    "index": 213,
    "question": "Aku dipake di leher. Ukuranku besar atau kecil. Aku berwarna-warni. Aku identik dengan wanita.",
    "answer": "Kalung"
  },
  {
    "index": 214,
    "question": "Aku sebuah kertas, namun aku dijadikan kebutuhan sehari-hari yang memiliki nominal.",
    "answer": "Uang"
  },
  {
    "index": 215,
    "question": "Aku seekor hewan yang berkulit tebal, berwarna abu-abu. Aku memiliki cula.",
    "answer": "Badak"
  },
  {
    "index": 216,
    "question": "Aku terdapat di bagian bawah pohon atau tanaman. Aku menancap pada tanah.",
    "answer": "Akar"
  },
  {
    "index": 217,
    "question": "Aku sebuah tempat yang sangat luas, pesawat selalu datang mengunjungi aku. Aku juga sangat sibuk sekali dan tidak pernah tutup. Aku banyak dicari oleh para pengguna transportasi untuk bepergian antar negara.",
    "answer": "Bandara"
  },
  {
    "index": 218,
    "question": "Aku adalah hasil fermentasi susu. Rasaku asam. Aku memiliki warna kuning.",
    "answer": "Keju"
  },
  {
    "index": 219,
    "question": "Aku adalah sebuah kendaraan. Aku biasanya mengantarkan orang ke berbagai pulau. Aku tidak dapat berfungsi bila berada di darat.",
    "answer": "Perahu"
  },
  {
    "index": 220,
    "question": "Aku sebagai bahan dasar untuk membuat baju. Aku tipis dan halus. Aku dibeli dengan ukuran per meter.",
    "answer": "Kain"
  },
  {
    "index": 221,
    "question": "Aku digunakan untuk merapihkan. Aku bisa membuat rambut menjadi menarik.",
    "answer": "Sisir"
  },
  {
    "index": 222,
    "question": "Tugas utamaku adalah mengoyak makanan. Aku memiliki bentuk yang runcing. Aku berada di mulut.",
    "answer": "Taring"
  },
  {
    "index": 223,
    "question": "Aku memiliki rasa yang pahit, tetapi aku sangat dibutuhkan oleh orang yang sakit.",
    "answer": "Obat"
  },
  {
    "index": 224,
    "question": "Aku berada di pegunungan, dalam peribahasa aku juga dikaitkan dengan menabung.",
    "answer": "Bukit"
  },
  {
    "index": 225,
    "question": "Aku memiliki bentuk tabung. Aku dapat menampung minyak dengan jumlah yang cukup banyak.",
    "answer": "Drum"
  },
  {
    "index": 226,
    "question": "Aku menghasilkan cahaya sendiri. Kalau dilihat dari bumi aku sangat kecil.",
    "answer": "Bintang"
  },
  {
    "index": 227,
    "question": "Tugas utamaku adalah melatih.",
    "answer": "Pelatih"
  },
  {
    "index": 228,
    "question": "Aku memiliki sifat yang sangat panas. Aku berasal dari gunung berapi.",
    "answer": "Lahar"
  },
  {
    "index": 229,
    "question": "Aku berada di daerah pegunungan. Aku dapat mengurangi pandangan pengendara. Aku sering muncul di pagi hari.",
    "answer": "Kabut"
  },
  {
    "index": 230,
    "question": "Tebak siapakah aku? Aku berada di leher. Aku juga berada di kemeja. Aku akan rapih bila dilipat.",
    "answer": "Kerah"
  },
  {
    "index": 231,
    "question": "Aku seorang omnivora. Aku juga seorang invertebrata. Aku dapat mengangkat sampai tiga kali berat badan mereka. Aku lebih kecil daripada klip kertas.",
    "answer": "Semut"
  },
  {
    "index": 232,
    "question": "Aku satu-satunya mamalia bersayap. Aku tinggal di daerah tropis dan beriklim sedang. Makananku dapat bervariasi dari buah-buahan, serbuk sari, dan nektar, hingga darah hewan lain.",
    "answer": "Kelelawar"
  },
  {
    "index": 233,
    "question": "Aku seorang invertebrata. Aku tinggal di sepanjang pantai. Aku memiliki dua capit untuk melindungi diri.",
    "answer": "Kepiting"
  },
  {
    "index": 234,
    "question": "Aku adalah mamalia darat terbesar. Aku makan sampai 350 pound per hari. Aku memiliki hidung yang panjang.",
    "answer": "Gajah"
  },
  {
    "index": 235,
    "question": "Aku tidak bisa dibakar. Aku juga tidak bisa ditenggelamkan ke dalam air.",
    "answer": "Es"
  },
  {
    "index": 236,
    "question": "Aku mudah terbuang dan tapi tidak bisa dihentikan.",
    "answer": "Waktu"
  },
  {
    "index": 237,
    "question": "Aku kehilangan kepalaku di pagi hari dan mendapatkan kembali di malam hari.",
    "answer": "Bantal"
  },
  {
    "index": 238,
    "question": "Aku adalah cara untuk mengucapkan sampai jumpa kepada kekasih atau kerabat.",
    "answer": "Peluk"
  },
  {
    "index": 239,
    "question": "Aku adalah mineral penting untuk kesehatan Anda.",
    "answer": "Vitamin"
  },
  {
    "index": 240,
    "question": "Aku bisa berlari sampai 35 mil per jam. Aku makan ratusan pon dedaunan dalam seminggu. Tinggi badanku membantuku untuk waspada terhadap predator. Aku adalah mamalia tertinggi.",
    "answer": "Jerapah"
  },
  {
    "index": 241,
    "question": "Aku suka memutar tapi kepalaku tetap tegak. Setelah aku masuk, aku menjadi ketat.",
    "answer": "Sekrup"
  },
  {
    "index": 242,
    "question": "Aku seorang mamalia. Aku juga seorang herbivora. Ketika aku takut, aku akan lari. Aku memiliki telinga yang besar untuk membantu aku mendengar.",
    "answer": "Kelinci"
  },
  {
    "index": 243,
    "question": "Aku seorang mamalia. Aku juga seorang karnivora. Aku berburu di malam hari. Aku adalah kucing terbesar dan terkuat.",
    "answer": "Harimau"
  },
  {
    "index": 244,
    "question": "Aku seorang invertebrata. Aku menyerap oksigen dan melepaskan karbon. Aku menjalani sebagian besar hidup saya di bawah tanah.",
    "answer": "Cacing"
  },
  {
    "index": 245,
    "question": "Aku lebih tinggi dari raja.",
    "answer": "Mahkota"
  },
  {
    "index": 246,
    "question": "Aku terbang, namun aku tidak memiliki sayap. Aku menangis, namun aku tidak punya mata. Aku bisa membuat langit jadi gelap dan terang.",
    "answer": "Awan"
  },
  {
    "index": 247,
    "question": "Aku memiliki kaki di kepala aku.",
    "answer": "Kutu"
  },
  {
    "index": 248,
    "question": "Aku adalah komputer bertenaga surya mini.",
    "answer": "Kalkulator"
  },
  {
    "index": 249,
    "question": "Semakin pendek saya, semakin besar saya.",
    "answer": "Suhu"
  },
  {
    "index": 250,
    "question": "Aku berasal dari laut dan berwarna putih seperti salju. Ketika aku kembali ke air, aku hilang tanpa bekas.",
    "answer": "Garam"
  },
  {
    "index": 251,
    "question": "Tebak siapakah aku? Aku cepat saat kurus. Aku lamban saat gemuk. Angin adalah mimpi terburuk saya. Aku sangat berguna saat gelap gulita.",
    "answer": "Lilin"
  },
  {
    "index": 252,
    "question": "Aku lembut, berbulu, dan berada dekat dengan pintu. Akulah yang selalu tinggal di lantai.",
    "answer": "Keset"
  },
  {
    "index": 253,
    "question": "Aku bukan mainan meski banyak yang menggunakanku untuk kesenangan. Aku punya pantat, tapi aku tidak bisa buang air besar.",
    "answer": "Rokok"
  },
  {
    "index": 254,
    "question": "Aku bisa berenang, tapi tidak pernah basah. Aku bisa berlari, tapi tidak pernah bosan. Aku mengikutimu kemana-mana, tapi tidak pernah mengucapakan sepatah kata pun.",
    "answer": "Bayangan"
  },
  {
    "index": 255,
    "question": "Aku melihat apa yang kamu lihat, merasakan apa yang kamu rasakan. Aku tahu semua gerakanmu sebelum kamu melakukannya. Aku bahkan tahu gerakan yang tidak kamu buat.",
    "answer": "Otak"
  },
  {
    "index": 256,
    "question": "Aku sangat tips. Aku bisa jatuh dari sebuah bangunan dan tidak hancur, tapi di air aku akan hancur.",
    "answer": "Kertas"
  },
  {
    "index": 257,
    "question": "Aku tempat Titanic berada saat ini.",
    "answer": "Atlantik"
  },
  {
    "index": 258,
    "question": "Kamu perlu ribuan aku untuk membuat gambar digital.",
    "answer": "Pixel"
  },
  {
    "index": 259,
    "question": "Jika kamu memiliki aku, kamu ingin berbagi aku. Begitu kamu berbagi aku, kamu tidak memiliki aku lagi.",
    "answer": "Rahasia"
  },
  {
    "index": 260,
    "question": "Setiap orang membutuhkan aku tapi mereka memberi saya pergi setiap hari.",
    "answer": "Uang"
  },
  {
    "index": 261,
    "question": "Anda membuangku di laut saat Anda menggunakan aku dan membawa aku masuk lagi saat Anda selesai.",
    "answer": "Jangkar"
  },
  {
    "index": 262,
    "question": "Aku adalah sejenis burung. Aku memiliki dua mata di depan dan banyak mata di ekor saya.",
    "answer": "Merak"
  },
  {
    "index": 263,
    "question": "Semakin cepat kamu berlari, semakin sulit untuk menangkap aku.",
    "answer": "Nafas"
  },
  {
    "index": 264,
    "question": "Aku digunakan untuk menyeberangi sungai. Aku berada di atas air.",
    "answer": "Jembatan"
  },
  {
    "index": 265,
    "question": "Aku adalah surga kecil yang dikelilingi oleh kekeringan dan panas. Aku biasanya terdapat di padang pasir.",
    "answer": "Oasis"
  },
  {
    "index": 266,
    "question": "Aku adalah tempat di akhirat yang berisi orang-orang baik.",
    "answer": "Surga"
  },
  {
    "index": 267,
    "question": "Aku lima bersaudara yang memiliki Ibu tapi tak berbapak.",
    "answer": "Jari"
  }
]

module.exports = Games