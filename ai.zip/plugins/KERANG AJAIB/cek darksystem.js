const config = require('@config');
const { sendMessageWithMention } = require('@lib/utils');

async function handle(sock, messageInfo) {
    const { remoteJid, message, fullText, sender, content, mentionedJid, prefix, command } = messageInfo;

    // Pastikan ada orang yang ditandai
    if (!mentionedJid?.length) {
        return sock.sendMessage(remoteJid, { text: `_⚠️ Format Penggunaan:_ \n\n_💬 Contoh:_ _*${prefix + command} @TAG*_` }, { quoted: message });
    }

    // Cek apakah yang ditandai adalah owner
    const isOwner = `${config.owner_number}@s.whatsapp.net` === mentionedJid[0];

    // Tentukan array kemungkinan jawaban
    const gan = isOwner
        ? ['mitik immortal'] // Jawaban spesial untuk owner
        : ['warior','elite','master','grenmaster','epik','lengens','mitik','mitik honor','mitik glory','mitik immortal']; // Jawaban standar

    // Pilih jawaban secara acak
    const selectedAnswer = gan[Math.floor(Math.random() * gan.length)];

    // Format pesan dengan menyebutkan user yang ditandai
    const responseText = `*Pertanyaan:* ${fullText}\n\n*Jawaban:* ${selectedAnswer}`;

    try {
        // Kirim pesan dengan menyebutkan orang yang ditandai
        await sendMessageWithMention(sock, remoteJid, responseText, message);
    } catch (error) {
        console.error('Error sending message:', error);
    }
}

module.exports = {
    handle,
    Commands    : ["cekdarksystem","cekpoke"],
    OnlyPremium : false,
    OnlyOwner   : false
};
