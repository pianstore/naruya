const { tiktok }        = require('@scrape/tiktok');
const { extractLink }   = require('@lib/utils');
const { logCustom }     = require("@lib/logger");

/**
 * Mengirim pesan dengan kutipan (quoted message)
 */
async function sendMessageWithQuote(sock, remoteJid, message, text) {
    await sock.sendMessage(remoteJid, { text }, { quoted: message });
}

/**
 * Memvalidasi apakah URL yang diberikan adalah URL TikTok yang valid
 */
function isTikTokUrl(url) {
    return /tiktok\.com/i.test(url);
}

/**
 * Fungsi utama untuk menangani perintah TikTok
 */
async function handle(sock, messageInfo) {
    const { remoteJid, message, content, prefix, command } = messageInfo;

    const validLink = extractLink(content);

    try {
        if (!content.trim()) {
            return sendMessageWithQuote(
                sock,
                remoteJid,
                message,
                `_⚠️ Format Penggunaan:_ \n\n_💬 Contoh:_ _*${prefix + command} linknya*_`
            );
        }

        if (!isTikTokUrl(validLink)) {
            return sendMessageWithQuote(
                sock,
                remoteJid,
                message,
                'URL yang Anda masukkan tidak valid. Pastikan URL berasal dari TikTok.'
            );
        }

        await sock.sendMessage(remoteJid, { react: { text: "⏰", key: message.key } });

        const response = await tiktok(validLink);

        await sock.sendMessage(remoteJid, {
            video: { url: response.no_watermark },
            caption: response.title
        }, { quoted: message });

        // Reaksi selesai ✅
        await sock.sendMessage(remoteJid, { react: { text: "✅", key: message.key } });

    } catch (error) {
        console.error("Kesalahan saat memproses perintah TikTok:", error);
        logCustom('info', content, `ERROR-COMMAND-${command}.txt`);

        const errorMessage = `Maaf, terjadi kesalahan saat memproses permintaan Anda. Mohon coba lagi nanti.\n\n*Detail Kesalahan:* ${error.message || error}`;
        await sendMessageWithQuote(sock, remoteJid, message, errorMessage);
    }
}

module.exports = {
    handle,
    Commands        : ['tt','tiktok'],
    OnlyPremium     : false, 
    OnlyOwner       : false,
    limitDeduction  : 20
};