const yts = require('yt-search');
const ApiAutoresbot = require('api-autoresbot');
const config = require('@config');
const { logCustom } = require("@lib/logger");

// Menyimpan interval loading per pengguna
const loadingIntervals = {};

// Animasi reaksi loading cepat dan langsung muncul
function startLoadingReaction(sock, message, id = 'default') {
    const clocks = ['🕒', '🕕', '🕘', '🕛'];
    let i = 0;

    // Langsung kirim reaksi pertama
    sendReaction(sock, message, clocks[i % clocks.length]);
    i++;

    const interval = setInterval(() => {
        sendReaction(sock, message, clocks[i % clocks.length]);
        i++;
    }, 1000);

    loadingIntervals[id] = interval;
}

// Hentikan reaksi loading
function stopLoadingReaction(id = 'default') {
    if (loadingIntervals[id]) {
        clearInterval(loadingIntervals[id]);
        delete loadingIntervals[id];
    }
}

// Kirim pesan dengan quote
async function sendMessageWithQuote(sock, remoteJid, message, text) {
    return sock.sendMessage(remoteJid, { text }, { quoted: message });
}

// Kirim reaksi
async function sendReaction(sock, message, reaction) {
    return sock.sendMessage(message.key.remoteJid, { react: { text: reaction, key: message.key } });
}

// Pencarian YouTube
async function searchYouTube(query) {
    const searchResults = await yts(query);
    return searchResults.all.find(item => item.type === 'video') || searchResults.all[0];
}

// Fungsi utama
async function handle(sock, messageInfo) {
    const { remoteJid, message, content, prefix, command } = messageInfo;

    try {
        const query = content.trim();
        if (!query) {
            return sendMessageWithQuote(
                sock,
                remoteJid,
                message,
                `_⚠️ Format Penggunaan:_ \n\n_💬 Contoh:_ _*${prefix + command} the night we meet*_`
            );
        }

        // Reaksi loading langsung
        startLoadingReaction(sock, message, remoteJid);

        const video = await searchYouTube(query);
        if (!video || !video.url) {
            stopLoadingReaction(remoteJid);
            await sendReaction(sock, message, "❌");
            return sendMessageWithQuote(sock, remoteJid, message, '⛔ _Tidak dapat menemukan video yang sesuai_');
        }

        if (video.seconds > 3600) {
            stopLoadingReaction(remoteJid);
            await sendReaction(sock, message, "❌");
            return sendMessageWithQuote(sock, remoteJid, message, '_Maaf, video terlalu besar untuk dikirim melalui WhatsApp._');
        }

        const api = new ApiAutoresbot(config.APIKEY);
        const response = await api.get('/api/downloader/ytplay', {
            url: video.url,
            format: 'm4a'
        });

        if (!response || !response.status) {
            stopLoadingReaction(remoteJid);
            await sendReaction(sock, message, "❌");
            return sendMessageWithQuote(sock, remoteJid, message, config.error.PLAY_ERROR);
        }

        if (response.bytes > 94491648) {
            stopLoadingReaction(remoteJid);
            await sendReaction(sock, message, "❌");
            return sendMessageWithQuote(sock, remoteJid, message, config.error.FILE_TOO_LARGE);
        }

        await sock.sendMessage(remoteJid, {
            audio: { url: response.url },
            mimetype: "audio/mp4",
            contextInfo: {
                externalAdReply: {
                    showAdAttribution: true,
                    title: video.title || "Untitled",
                    body: config.owner_name,
                    sourceUrl: video.url,
                    thumbnailUrl: video.thumbnail || "https://example.com/default_thumbnail.jpg",
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: message });

        stopLoadingReaction(remoteJid);
        await sendReaction(sock, message, "✅");

    } catch (error) {
        console.error("Error while handling command:", error);
        stopLoadingReaction(remoteJid);
        await sendReaction(sock, message, "❌");
        logCustom('info', content, `ERROR-COMMAND-${command}.txt`);
        const errorMessage = `⚠️ Maaf, terjadi kesalahan saat memproses permintaan Anda. Mohon coba lagi nanti.\n\n💡 Detail: ${error.message || error}`;
        await sendMessageWithQuote(sock, remoteJid, message, errorMessage);
    }
}

module.exports = {
    handle,
    Commands: ['play'],
    OnlyPremium: false,
    OnlyOwner: false,
    limitDeduction: 20,
};