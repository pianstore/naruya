const { findUser, updateUser, addUser } = require("@lib/users");
const { formatRemainingTime } = require("@lib/utils");

// Daftar owner (format JID WhatsApp)
const ownerJids = [
    "6285256833258@s.whatsapp.net",
    "628891768169@s.whatsapp.net"
];

async function handle(sock, messageInfo) {
    const { remoteJid, message, sender } = messageInfo;

    const CLAIM_COOLDOWN_MINUTES = 1000;
    const currentTime = Date.now();
    const CLAIM_COOLDOWN = CLAIM_COOLDOWN_MINUTES * 60 * 1000;

    const isOwner = ownerJids.includes(sender);

    // Owner: 1000–2000 | User: 10–20
    const MoneyClaim = isOwner
        ? Math.floor(Math.random() * (2000 - 1000 + 1)) + 1000
        : Math.floor(Math.random() * (20 - 10 + 1)) + 10;

    const LimitClaim = isOwner
        ? Math.floor(Math.random() * (2000 - 1000 + 1)) + 1000
        : Math.floor(Math.random() * (20 - 10 + 1)) + 10;

    const dataUsers = await findUser(sender);
    if (dataUsers) {
        if (!isOwner && dataUsers.lastClaim && currentTime - dataUsers.lastClaim < CLAIM_COOLDOWN) {
            const remainingTime = Math.floor((CLAIM_COOLDOWN - (currentTime - dataUsers.lastClaim)) / 1000);
            const formattedTime = formatRemainingTime(remainingTime);
            return await sock.sendMessage(
                remoteJid,
                { text: `🔒 _Kamu sudah klaim sebelumnya! Harap tunggu *${formattedTime}* lagi sebelum bisa klaim lagi._` },
                { quoted: message }
            );
        }

        await updateUser(sender, {
            money: dataUsers.money + MoneyClaim,
            limit: dataUsers.limit + LimitClaim,
            lastClaim: isOwner ? dataUsers.lastClaim : currentTime
        });

        return await sock.sendMessage(
            remoteJid,
            { text: `_Kamu dapat *${MoneyClaim}* money dan *${LimitClaim}* limit!_` },
            { quoted: message }
        );
    } else {
        await addUser(sender, {
            money: MoneyClaim,
            limit: LimitClaim,
            role: isOwner ? "owner" : "user",
            status: "active",
            lastClaim: isOwner ? 0 : currentTime
        });

        return await sock.sendMessage(
            remoteJid,
            { text: `Selamat datang! Kamu dapat *${MoneyClaim}* money dan *${LimitClaim}* limit.` },
            { quoted: message }
        );
    }
}

module.exports = {
    handle,
    Commands: ['claim'],
    OnlyPremium: false,
    OnlyOwner: false
};