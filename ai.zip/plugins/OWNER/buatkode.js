const fs = require("fs");
const path = require("path");
const { isOwner } = require("@lib/utils");

const REDEEM_FILE = path.join(__dirname, "../database/redeem.json");

function loadRedeemData() {
    if (!fs.existsSync(REDEEM_FILE)) fs.writeFileSync(REDEEM_FILE, "{}");
    return JSON.parse(fs.readFileSync(REDEEM_FILE));
}

function saveRedeemData(data) {
    fs.writeFileSync(REDEEM_FILE, JSON.stringify(data, null, 2));
}

async function handle(sock, messageInfo) {
    const { remoteJid, message, sender, args } = messageInfo;

    if (!isOwner(sender)) {
        return await sock.sendMessage(remoteJid, { text: "❌ Hanya owner yang bisa membuat kode." }, { quoted: message });
    }

    const [kode, uangStr, limitStr] = args;
    if (!kode || isNaN(uangStr) || isNaN(limitStr)) {
        return await sock.sendMessage(remoteJid, { text: "❗ Format: `!buatkode <kode> <money> <limit>`" }, { quoted: message });
    }

    const redeemData = loadRedeemData();

    if (redeemData[kode]) {
        return await sock.sendMessage(remoteJid, { text: "⚠️ Kode sudah ada." }, { quoted: message });
    }

    redeemData[kode] = {
        money: parseInt(uangStr),
        limit: parseInt(limitStr),
        used: false,
    };

    saveRedeemData(redeemData);

    return await sock.sendMessage(remoteJid, {
        text: `✅ Kode *${kode}* berhasil dibuat!
Money: *${uangStr}*
Limit: *${limitStr}*`,
    }, { quoted: message });
}

module.exports = {
    handle,
    Commands: ['buatkode'],
    OnlyPremium: false,
    OnlyOwner: true,
};