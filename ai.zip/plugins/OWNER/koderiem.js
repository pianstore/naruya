const fs = require("fs");
const path = require("path");
const { findUser, updateUser, addUser } = require("@lib/users");

const REDEEM_FILE = path.join(__dirname, "../database/redeem.json");

function loadRedeemData() {
    if (!fs.existsSync(REDEEM_FILE)) fs.writeFileSync(REDEEM_FILE, "{}");
    return JSON.parse(fs.readFileSync(REDEEM_FILE));
}

function saveRedeemData(data) {
    fs.writeFileSync(REDEEM_FILE, JSON.stringify(data, null, 2));
}

async function handle(sock, messageInfo) {
    const { remoteJid, message, sender, args } = messageInfo;

    const inputCode = args[0]?.trim();

    if (!inputCode) {
        return await sock.sendMessage(
            remoteJid,
            { text: "❗ Gunakan format: `!koderiem <kode>`" },
            { quoted: message }
        );
    }

    let redeemData = loadRedeemData();

    if (!redeemData[inputCode]) {
        return await sock.sendMessage(
            remoteJid,
            { text: "❌ Kode tidak valid." },
            { quoted: message }
        );
    }

    if (redeemData[inputCode].used) {
        return await sock.sendMessage(
            remoteJid,
            { text: "⚠️ Kode sudah digunakan." },
            { quoted: message }
        );
    }

    const reward = redeemData[inputCode];
    let user = await findUser(sender);
    const updateData = {
        money: (user?.money || 0) + reward.money,
        limit: (user?.limit || 0) + reward.limit,
    };

    if (user) {
        await updateUser(sender, updateData);
    } else {
        await addUser(sender, {
            money: reward.money,
            limit: reward.limit,
            role: "user",
            status: "active",
            lastClaim: 0,
        });
    }

    redeemData[inputCode].used = true;
    redeemData[inputCode].usedBy = sender;
    redeemData[inputCode].usedAt = Date.now();
    saveRedeemData(redeemData);

    return await sock.sendMessage(
        remoteJid,
        { text: `✅ Kamu mendapatkan *${reward.money}* money dan *${reward.limit}* limit!` },
        { quoted: message }
    );
}

module.exports = {
    handle,
    Commands: ['koderiem'],
    OnlyPremium: false,
    OnlyOwner: false,
};