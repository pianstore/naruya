const { readFileSync } = require("fs");
const path = require("path");

const OWNER_NUMBER = "6285256833258@s.whatsapp.net"; // GANTI DENGAN NOMER MU

async function process(sock, messageInfo) {
    const { remoteJid, isGroup, message } = messageInfo;
    if (!isGroup || !message) return;

    // INI UNTUK MENANGKAP MENTION
    const mentionedJid = message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    if (!mentionedJid.includes(OWNER_NUMBER)) return;

    try {
        // INI AMBIL AUDIO NYA
        const audioPath = "./media/owner.mp3";
        const audioBuffer = readFileSync(audioPath);
        if (!audioBuffer) return;

        await sock.sendMessage(remoteJid, {
            audio: audioBuffer,
            mimetype: 'audio/mp4',
            ptt: true
        }, { quoted: message });

    } catch (error) {
        console.error(error);
    }
}

module.exports = { 
    name: "OwnerVN", 
    priority: 11, 
    process 
};