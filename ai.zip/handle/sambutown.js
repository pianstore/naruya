const respondedSenders = new Map();
const { readFileAsBuffer } = require('@lib/fileHelper');
const { getGreeting } = require("@lib/utils");
const config = require("@config");

const OWNER_NUMBER = config.owner_number.map(num => `${num}@s.whatsapp.net`);

async function process(sock, messageInfo) {
    const { remoteJid, pushName, isGroup, message, sender } = messageInfo;

    if (!sender || !message || !isGroup) return; // Hanya lanjut jika pesan berasal dari grup
    if (!OWNER_NUMBER.includes(sender)) return; // Hanya untuk owner

    const lastResponseTime = respondedSenders.get(sender) || 0;
    const currentTime = Date.now();

    if (currentTime - lastResponseTime < 1000 * 60 * 1000) return; // Delay 10 menit
const salam = getGreeting();
    // Ambil foto owner
    let buffer;
    try {
        buffer = readFileAsBuffer("@assets/PP.jpg");
    } catch (err) {
        return;
    }

    // Fake contact message
    const fkon = {
        key: {
            fromMe: false,
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast"
        },
        message: {
            contactMessage: {
                displayName: pushName,
                vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:${pushName}\nTEL;waid=${sender.split('@')[0]}:+${sender.split('@')[0]}\nEND:VCARD`,
                jpegThumbnail: buffer // Gunakan buffer langsung
            }
        }
    };

    // Pesan balasan
    const response = `_halo owner @${sender.split("@")[0]}, *selamat ${salam} !*_`;

    try {
        await sock.sendMessage(remoteJid, { text: response, mentions: [sender] }, { quoted: fkon });
        respondedSenders.set(sender, currentTime);
    } catch (error) {
        return;
    }
}

module.exports = {
    name: "Owner",
    priority: 1,
    process
};