/*
╔═════════════════════════════════╗
║     🛠️ Informasi Script
╠═════════════════════════════════╣
║ 📦 Version   : 4.1.8
║ 👨‍💻 Developer : Azhari Creative    
║ 🌐 Website   : autoresbot.com   
╚═════════════════════════════════╝

⚠️ Peringatan: SCRIPT INI TIDAK BOLEH DIPERJUALBELIKAN
📌 Pembelian resmi hanya dapat dilakukan di website resmi: https://autoresbot.com
*/

const mess = {
    game: {
        isPlaying   : "⚠️ _permainan sedang berlangsung._ ketik *nyerah* untuk mengakhiri permainan.",
        isGroup     : "⚠️ _permainan hanya bisa dimainkan di grup_",
        isStop      : "⚠️ _fitur game dimatikan di grub ini_",
    },
    general : {
        isOwner     : '⚠️ _perintah ini hanya untuk owner bot._',
        isPremium   : '⚠️ _perintah ini hanya untuk pengguna premium._',
        isAdmin     : '⚠️ _perintah ini hanya untuk admin_',
        isGroup     : "⚠️ _perintah ini hanya digunakan di grup_",
        limit       : "⚠️ _limit kamu sudah habis_ \n\n_ketik *.claim* untuk mendapatkan limit_ _atau 💎 berlangganan member premium agar limitmu tanpa batas_",
        success     : "✅ _success kak_",
        isBlocked   : "⚠️ _kamu sedang di block dari penggunaan bot ini_", // kalau block seluruhnya
        isBaned     : "⚠️ _kamu sedang di ban pada grub ini_", // kalau ban hanya grub itu saja
        fiturBlocked: "⚠️ _fitur sedang di ban di grub ini_",
    },
    action : {
        grub_open   : '✅ grup berhasil dibuka',
        grub_close  : '✅ grup berhasil ditutup',
        user_kick   : '✅ _berhasil mengeluarkan peserta dari grup._',
        mute        : '_grup telah berhasil di-mute. semua perintah akan dinonaktifkan kecuali untuk menghidupkan kembali dengan mengetik_ *.unmute*.',
        unmute      : '_grup telah berhasil di-unmute. semua perintah kembali aktif._',
        resetgc     : '_link grub sudah di reset_',
    },
    handler : { // kosongkan jika tidak menggunakan notif = ''
        badword_warning : '⚠️ _*BADWORD TERDETEKSI*_\n\n@sender _telah diperingati_ (@warning/@totalwarning)',
        badword_block   : '⛔ @sender _telah diblokir karena mengirim *BADWORD* secara berulang. hubungi owner jika ada pertanyaan._',
        antiedit        : '⚠️ _*ANTI EDIT DETECTED*_\n\n_pesan sebelumnya_ : @oldMessage',
        antidelete      : '⚠️ _*ANTI DELETE DETECTED*_\n\n_pengirim_ : @sender \n_pesan sebelumnya_ : @text',
        antispamchat    : '⚠️ @sender _jangan spam, ini peringatan ke-@warning dari @totalwarning._',
        antispamchat2   : '⛔ @sender _telah diblokir karena melakukan spam secara berulang. hubungi owner jika ada pertanyaan._',
        antivirtex      : '⚠️ @sender _terdeteksi mengirim virtex._',
        antitagsw       : '⚠️ @sender _terdeteksi tag sw di grub ini_',
        antibot         : '⚠️ @sender _terdeteksi adalah bot_',
        afk             : '🚫 *jangan tag dia!*\n\n❏ _@sender sedang AFK sejak *@durasi*_@alasan',
        afk_message     : '🕊️ @sender telah kembali dari AFK sejak _*@durasi*_.@alasan',
        sewa_notif      : '⚠️ _*peringatan!*_\n\n_masa sewabot :_ @date',
        sewa_out        : `❌ _*masa sewabot telah habis*_\n_bot akan keluar otomatis_\n\nterima kasih sudah menggunakan layanan sewa ʜᴀɪᴋᴀʟ.\n\n*nomor owner*\nwa.me/@ownernumber`
    },
    game_handler        : {
        menyerah        : 'yahh menyerah\njawaban: @answer\n\nIngin bermain? ketik *@command*',
        waktu_habis     : '⏳ waktu habis! jawabannya : @answer',
        tebak_angka     : '🎉 selamat! tebakan anda benar. anda mendapatkan @hadiah money.',
        tebak_bendera   : '🎉 selamat! tebakan anda benar. anda mendapatkan @hadiah money.',
        tebak_gambar    : '🎉 selamat! tebakan anda benar. anda mendapatkan @hadiah money.',
        tebak_hewan     : '🎉 selamat! tebakan anda benar. anda mendapatkan @hadiah money.',
        tebak_kalimat   : '🎉 selamat! tebakan anda benar. anda mendapatkan @hadiah money.',
        tebak_kata      : '🎉 selamat! tebakan anda benar. anda mendapatkan @hadiah money.',
        tebak_lagu      : '🎉 selamat! tebakan anda benar. anda mendapatkan @hadiah money.',
        tebak_lirik     : '🎉 selamat! tebakan anda benar. anda mendapatkan @hadiah money.',
    }
};

// Variable
global.group = {};
global.group.variable = `
☍ @name
☍ @date
☍ @day
☍ @desc
☍ @group
☍ @greeting
☍ @size
☍ @time`;

module.exports = mess;